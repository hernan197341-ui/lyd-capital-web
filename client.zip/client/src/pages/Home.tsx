import Header from '@/components/Header';
import HeroSection from '@/components/HeroSection';
import LawSection from '@/components/LawSection';
import DatacreditUpload from '@/components/DatacreditUpload';
import CTASection from '@/components/CTASection';
import Footer from '@/components/Footer';

/**
 * Home Page - L y D Capital Landing Page
 * 
 * Design Philosophy: Professional Modern with Financial Trust
 * - Clean, hierarchical layout with asymmetric sections
 * - Paleta: Deep blue (trust) + White + Soft green (recovery)
 * - Typography: Playfair Display (titles) + Inter (body)
 * - Focus on clarity, accessibility, and user action
 */
export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-white">
      {/* Header Navigation */}
      <Header />

      {/* Main Content */}
      <main className="flex-grow">
        {/* Hero Section - First impression and value proposition */}
        <HeroSection />

        {/* Law 2157 Explanation - Educational content about the law */}
        <LawSection />

        {/* Datacrédito Upload - Interactive PDF upload section */}
        <DatacreditUpload />

        {/* CTA Section - Final call to action */}
        <CTASection />
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
}
