import { CheckCircle2, FileText, Scale, TrendingUp, MessageCircle } from 'lucide-react';

/**
 * Services Page Component
 * Design: Professional services showcase with clear descriptions and CTAs
 * Displays the three main services offered by L y D Capital
 */
export default function Services() {
  const whatsappNumber = '+573142576858';
  const whatsappMessage = encodeURIComponent('Hola, me gustaría conocer más sobre los servicios de L y D Capital. ¿Cuál es el proceso?');
  const whatsappLink = `https://wa.me/${whatsappNumber}?text=${whatsappMessage}`;

  const services = [
    {
      id: 1,
      title: 'Análisis de Datacrédito',
      icon: FileText,
      description: 'Revisión completa y detallada de tu reporte de Datacrédito. Identificamos deudas, errores y oportunidades de mejora en tu historial crediticio.',
      features: [
        'Revisión exhaustiva del reporte',
        'Identificación de deudas activas',
        'Detección de errores o fraudes',
        'Análisis de impacto crediticio',
        'Recomendaciones personalizadas'
      ],
      color: 'from-blue-500 to-blue-600'
    },
    {
      id: 2,
      title: 'Asesoría Ley 2157 de 2021',
      icon: Scale,
      description: 'Asesoramiento especializado sobre la Ley Borrón y Cuenta Nueva. Te explicamos tus derechos, requisitos y cómo acceder a los beneficios de esta ley.',
      features: [
        'Explicación clara de la ley',
        'Evaluación de tu elegibilidad',
        'Requisitos y documentación',
        'Estrategia personalizada',
        'Acompañamiento legal'
      ],
      color: 'from-green-500 to-green-600'
    },
    {
      id: 3,
      title: 'Seguimiento al Proceso',
      icon: TrendingUp,
      description: 'Acompañamiento continuo durante todo el proceso de recuperación crediticia. Monitoreamos tu caso y te mantenemos informado en cada paso.',
      features: [
        'Seguimiento mensual',
        'Reportes de progreso',
        'Actualización de Datacrédito',
        'Asesoría en cada etapa',
        'Apoyo hasta la recuperación'
      ],
      color: 'from-purple-500 to-purple-600'
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white border-b border-slate-200">
        <div className="container py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-700 rounded-lg flex items-center justify-center">
              <span className="text-white font-display font-bold">LyD</span>
            </div>
            <div>
              <h1 className="font-display font-bold text-blue-900">L y D Capital</h1>
              <p className="text-xs text-slate-600">Consultoría Financiera</p>
            </div>
          </div>
          <nav className="hidden md:flex items-center gap-8">
            <a href="/" className="text-slate-600 hover:text-blue-900 transition-colors">Inicio</a>
            <a href="/services" className="text-blue-900 font-semibold">Servicios</a>
            <a href="/#ley" className="text-slate-600 hover:text-blue-900 transition-colors">Ley 2157</a>
            <a href="/#datacredito" className="text-slate-600 hover:text-blue-900 transition-colors">Cargar Datacrédito</a>
            <a
              href={whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-green-500 hover:bg-green-600 text-white font-semibold py-2 px-6 rounded-lg transition-colors"
            >
              WhatsApp
            </a>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 md:py-24 bg-gradient-to-br from-blue-900 to-blue-800">
        <div className="container">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-display font-bold text-white mb-6 leading-tight">
              Nuestros Servicios
            </h1>
            <p className="text-xl text-blue-100 leading-relaxed">
              En L y D Capital ofrecemos soluciones integrales para recuperar tu estabilidad financiera. Cada servicio está diseñado para ayudarte en tu camino hacia la libertad crediticia.
            </p>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-16 md:py-24">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {services.map((service) => {
              const IconComponent = service.icon;
              return (
                <div
                  key={service.id}
                  className="bg-white border border-slate-200 rounded-xl overflow-hidden hover:shadow-lg transition-shadow duration-300"
                >
                  {/* Service Header */}
                  <div className={`bg-gradient-to-r ${service.color} p-8 text-white`}>
                    <IconComponent size={48} className="mb-4" />
                    <h2 className="text-2xl font-display font-bold">{service.title}</h2>
                  </div>

                  {/* Service Content */}
                  <div className="p-8">
                    <p className="text-slate-600 mb-6 leading-relaxed">
                      {service.description}
                    </p>

                    {/* Features List */}
                    <div className="space-y-3 mb-8">
                      {service.features.map((feature, index) => (
                        <div key={index} className="flex items-start gap-3">
                          <CheckCircle2 size={20} className="text-green-500 flex-shrink-0 mt-0.5" />
                          <span className="text-slate-700">{feature}</span>
                        </div>
                      ))}
                    </div>

                    {/* CTA Button */}
                    <a
                      href={whatsappLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 w-full justify-center bg-green-500 hover:bg-green-600 text-white font-semibold py-3 px-6 rounded-lg transition-colors"
                    >
                      <MessageCircle size={20} />
                      Consultar Servicio
                    </a>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-16 md:py-24 bg-slate-50">
        <div className="container">
          <h2 className="text-3xl md:text-4xl font-display font-bold text-blue-900 mb-12 text-center">
            Cómo Funciona Nuestro Proceso
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[
              { step: '1', title: 'Consulta Inicial', desc: 'Contacta por WhatsApp para una consulta gratuita' },
              { step: '2', title: 'Análisis', desc: 'Revisamos tu Datacrédito y situación financiera' },
              { step: '3', title: 'Plan Personalizado', desc: 'Diseñamos una estrategia según tu caso' },
              { step: '4', title: 'Recuperación', desc: 'Acompañamiento hasta lograr tu estabilidad' }
            ].map((item, index) => (
              <div key={index} className="relative">
                <div className="bg-white p-6 rounded-lg border border-slate-200 text-center">
                  <div className="w-12 h-12 bg-blue-900 text-white rounded-full flex items-center justify-center font-bold text-lg mx-auto mb-4">
                    {item.step}
                  </div>
                  <h3 className="font-semibold text-slate-900 mb-2">{item.title}</h3>
                  <p className="text-sm text-slate-600">{item.desc}</p>
                </div>
                {index < 3 && (
                  <div className="hidden md:block absolute top-1/2 -right-3 w-6 h-0.5 bg-blue-900 transform -translate-y-1/2" />
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 bg-gradient-to-br from-blue-900 to-blue-800">
        <div className="container text-center">
          <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-6">
            ¿Listo para Recuperar tu Estabilidad Financiera?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Nuestro equipo de expertos está disponible 24/7 para ayudarte. Contacta por WhatsApp hoy mismo.
          </p>
          <a
            href={whatsappLink}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-green-500 hover:bg-green-600 text-white font-bold py-4 px-10 rounded-lg transition-colors text-lg"
          >
            <MessageCircle size={24} />
            Consulta Gratuita por WhatsApp
          </a>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-300 py-12">
        <div className="container text-center text-sm">
          <p>&copy; 2026 L y D Capital. Todos los derechos reservados.</p>
          <p className="mt-4 text-xs text-slate-500">
            <strong>Descargo:</strong> L y D Capital proporciona consultoría financiera. Consulte con un profesional certificado antes de tomar decisiones importantes.
          </p>
        </div>
      </footer>
    </div>
  );
}
