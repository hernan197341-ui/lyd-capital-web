export interface BlogArticle {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  image: string;
  imageCompressed: string;
  category: string;
  date: string;
  author: string;
  readTime: number;
}

export const blogArticles: BlogArticle[] = [
  {
    id: "ley-2157-basics",
    title: "Ley 2157 de 2021: ¿Qué es el Borrón y Cuenta Nueva?",
    excerpt: "Descubre cómo la Ley 2157 te ofrece una segunda oportunidad para recuperar tu estabilidad financiera y acceder nuevamente a créditos.",
    content: `
# Ley 2157 de 2021: ¿Qué es el Borrón y Cuenta Nueva?

## Introducción

La **Ley 2157 de 2021**, conocida popularmente como "Borrón y Cuenta Nueva", es una legislación colombiana que representa una oportunidad de recuperación financiera para miles de personas que enfrentan dificultades con su historial crediticio.

## ¿Qué es exactamente?

La Ley 2157 es un mecanismo legal que permite a personas naturales con dificultades financieras **limpiar su historial crediticio** ante las centrales de riesgo (Datacrédito, Equifax, Transunión, CIFIN) bajo ciertas condiciones.

## Requisitos principales

Para acceder a los beneficios de la Ley 2157, debes cumplir con:

1. **Ser persona natural** (no aplica para empresas)
2. **Tener deudas vencidas** en tu historial crediticio
3. **Demostrar intención de pago** a través de acuerdos de pago
4. **Cumplir con los pagos acordados** durante el proceso

## Beneficios clave

- **Eliminación de reportes negativos** en centrales de riesgo
- **Acceso nuevamente a créditos** después del proceso
- **Mejora de tu score crediticio**
- **Oportunidad de vivienda, vehículo y otros créditos**
- **Recuperación de tu reputación financiera**

## Duración del proceso

El tiempo para ver resultados varía, pero generalmente:
- Análisis inicial: 1-2 semanas
- Negociación con acreedores: 2-4 semanas
- Implementación de acuerdos: 3-6 meses
- Limpieza de reportes: 4-12 meses

## Próximos pasos

Si crees que cumples con los requisitos, es momento de actuar. Contacta con nuestros expertos para una consulta gratuita y descubre cómo podemos ayudarte a recuperar tu libertad financiera.
    `,
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663589446534/ew8NCBZTZqrhWkeojEJW8P/blog-article-1-ley2157-basics-QxroDpxMUz5Vg7TdLURGXZ.png",
    imageCompressed: "https://d2xsxph8kpxj0f.cloudfront.net/310519663589446534/ew8NCBZTZqrhWkeojEJW8P/blog-article-1-ley2157-basics-AYVu2z6crqcQy7bwDsvh9b.webp",
    category: "Ley 2157",
    date: "2026-04-20",
    author: "L y D Capital",
    readTime: 5,
  },
  {
    id: "entender-datacrédito",
    title: "¿Cómo funciona Datacrédito? Guía completa para entender tu reporte",
    excerpt: "Aprende a interpretar tu reporte de Datacrédito y entiende qué información afecta tu score crediticio.",
    content: `
# ¿Cómo funciona Datacrédito? Guía completa para entender tu reporte

## ¿Qué es Datacrédito?

**Datacrédito** es la central de riesgo más grande de Colombia. Es una empresa que recopila, almacena y reporta información sobre el comportamiento crediticio de personas naturales y jurídicas.

## ¿Por qué es importante?

Tu reporte de Datacrédito es como tu "historial financiero". Los bancos, tiendas y otras instituciones lo consultan antes de otorgarte un crédito. Un buen reporte significa:
- Acceso más fácil a créditos
- Mejores tasas de interés
- Mayor confianza de los acreedores

## Componentes de tu reporte

### 1. Información personal
- Nombre, cédula, dirección
- Datos de contacto

### 2. Historial de créditos
- Créditos activos
- Créditos pagados
- Créditos vencidos

### 3. Score crediticio
- Puntuación de 0 a 900
- Determina tu confiabilidad

### 4. Reportes negativos
- Pagos vencidos
- Cuentas en cobranza
- Deudas castigadas

## Cómo mejorar tu reporte

1. **Pagar a tiempo** - Cumple con tus obligaciones
2. **Reducir deudas** - Disminuye tu endeudamiento
3. **Diversificar créditos** - Varía tipos de crédito
4. **Limpiar reportes negativos** - Usa la Ley 2157
5. **Monitorear regularmente** - Revisa cambios

## Acciones inmediatas

Solicita tu reporte de Datacrédito hoy y descubre tu situación actual. Nuestro equipo puede ayudarte a interpretarlo y crear un plan de acción.
    `,
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663589446534/ew8NCBZTZqrhWkeojEJW8P/blog-article-2-datacrédito-exgAxPwixdU7WLMXoPbM6V.png",
    imageCompressed: "https://d2xsxph8kpxj0f.cloudfront.net/310519663589446534/ew8NCBZTZqrhWkeojEJW8P/blog-article-2-datacrédito-P9k7MfDqRdP59JC8KdsJZk.webp",
    category: "Educación Financiera",
    date: "2026-04-18",
    author: "L y D Capital",
    readTime: 6,
  },
  {
    id: "planificación-financiera",
    title: "5 pasos para crear un plan financiero sólido en 2026",
    excerpt: "Descubre cómo planificar tus finanzas personales y construir un futuro financiero estable y seguro.",
    content: `
# 5 pasos para crear un plan financiero sólido en 2026

## Introducción

Un plan financiero es tu hoja de ruta hacia la estabilidad económica. Sin él, es fácil perder el control de tus gastos y deudas. Aquí te presentamos 5 pasos prácticos para crear un plan que funcione.

## Paso 1: Evalúa tu situación actual

Antes de planificar, necesitas saber dónde estás:
- **Calcula tu ingreso mensual** - Suma todos tus ingresos
- **Lista tus gastos** - Todos, incluso los pequeños
- **Identifica tus deudas** - Créditos, tarjetas, préstamos
- **Calcula tu patrimonio neto** - Activos menos pasivos

## Paso 2: Establece metas financieras

Define qué quieres lograr:
- **Corto plazo** (3-6 meses): Ahorrar para emergencias
- **Mediano plazo** (1-2 años): Pagar deudas específicas
- **Largo plazo** (5+ años): Vivienda, educación, retiro

## Paso 3: Crea un presupuesto realista

Tu presupuesto debe incluir:
- **Ingresos**: Dinero que entra
- **Gastos fijos**: Arriendo, servicios, etc.
- **Gastos variables**: Comida, transporte, entretenimiento
- **Ahorros**: Al menos 10% de tu ingreso

## Paso 4: Implementa una estrategia de ahorro

- **Automatiza tus ahorros** - Transfiere dinero el día que cobras
- **Usa cuentas separadas** - Mantén el ahorro apartado
- **Empieza pequeño** - Incluso $50 mil mensuales ayuda
- **Aumenta gradualmente** - Incrementa conforme mejore tu situación

## Paso 5: Monitorea y ajusta

- **Revisa mensualmente** - Verifica progreso
- **Ajusta según necesidad** - Adapta a cambios
- **Celebra logros** - Reconoce tu progreso
- **Busca asesoría** - Consulta expertos si lo necesitas

## Conclusión

Un plan financiero no es complicado, solo requiere disciplina y consistencia. Comienza hoy y verás resultados en poco tiempo.
    `,
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663589446534/ew8NCBZTZqrhWkeojEJW8P/blog-article-3-financial-planning-5WG4BEpmaQZo4s7sc26RaE.png",
    imageCompressed: "https://d2xsxph8kpxj0f.cloudfront.net/310519663589446534/ew8NCBZTZqrhWkeojEJW8P/blog-article-3-financial-planning-Tb4DHSq5reZDv49bFXYocr.webp",
    category: "Educación Financiera",
    date: "2026-04-15",
    author: "L y D Capital",
    readTime: 7,
  },
  {
    id: "historias-éxito",
    title: "Historias de éxito: Cómo nuestros clientes recuperaron su libertad financiera",
    excerpt: "Conoce las historias reales de personas que utilizaron la Ley 2157 para transformar sus vidas financieras.",
    content: `
# Historias de éxito: Cómo nuestros clientes recuperaron su libertad financiera

## Introducción

Cada día, personas en Colombia enfrentan dificultades financieras. Pero también cada día, muchas de ellas encuentran soluciones. Aquí compartimos historias reales de transformación.

## Historia 1: María - De la desesperación a la esperanza

**Situación inicial:**
- Deudas por $45 millones en 5 bancos diferentes
- Score crediticio: 350 (muy bajo)
- Rechazada en múltiples solicitudes de crédito
- Depresión y estrés financiero

**Proceso:**
- Análisis completo de su situación
- Negociación con acreedores
- Plan de pago estructurado
- Seguimiento mensual

**Resultado (8 meses después):**
- Deudas reducidas a $12 millones
- Score crediticio: 650 (bueno)
- Aprobada para crédito de vivienda
- Recuperó su confianza y paz mental

*"No pensé que fuera posible. Ahora tengo mi propia casa. Gracias L y D Capital."* - María

## Historia 2: Carlos - Empresario que necesitaba recuperarse

**Situación inicial:**
- Fracaso de negocio dejó deudas de $80 millones
- Reportes negativos en todas las centrales
- Imposibilidad de acceder a créditos
- Sentimiento de fracaso

**Proceso:**
- Reestructuración de deudas
- Negociación con instituciones financieras
- Plan de recuperación de 12 meses
- Mentoría en gestión financiera

**Resultado (12 meses después):**
- Deudas pagadas en 80%
- Reportes limpios en 3 centrales
- Nuevo negocio con acceso a financiamiento
- Recuperó su confianza empresarial

*"Pensé que mi carrera había terminado. Hoy tengo un nuevo negocio y mejor control financiero."* - Carlos

## Historia 3: Ana y su familia - Recuperando el sueño de la vivienda

**Situación inicial:**
- Deudas acumuladas: $35 millones
- Rechazada para hipoteca
- Familia viviendo en arriendo
- Sueño de vivienda propia parecía imposible

**Proceso:**
- Análisis integral de finanzas familiares
- Estrategia de pago agresiva pero realista
- Limpieza de reportes negativos
- Preparación para solicitud hipotecaria

**Resultado (10 meses después):**
- Deudas reducidas a $5 millones
- Aprobada para hipoteca de $200 millones
- Familia en su propia casa
- Estabilidad financiera lograda

*"Nuestro sueño de tener casa propia se hizo realidad. Fue el mejor regalo que pudimos darle a nuestros hijos."* - Ana

## Lecciones aprendidas

De estas historias podemos extraer:

1. **No importa cuán grave sea la situación** - Siempre hay soluciones
2. **La consistencia es clave** - Cumplir con los acuerdos funciona
3. **El apoyo profesional acelera resultados** - Los expertos marcan la diferencia
4. **La transformación es posible** - Muchos lo han logrado

## Tu historia puede ser la próxima

Si te identificas con alguna de estas historias, es momento de actuar. Contacta con nosotros para una consulta gratuita y comienza tu propio camino hacia la libertad financiera.
    `,
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663589446534/ew8NCBZTZqrhWkeojEJW8P/blog-article-4-success-stories-68jhu5U363mhRWgoZ6SaVV.png",
    imageCompressed: "https://d2xsxph8kpxj0f.cloudfront.net/310519663589446534/ew8NCBZTZqrhWkeojEJW8P/blog-article-4-success-stories-SHNYj5mJuXLhpRbDBXCMVH.webp",
    category: "Historias de Éxito",
    date: "2026-04-10",
    author: "L y D Capital",
    readTime: 8,
  },
];

export function getArticleById(id: string): BlogArticle | undefined {
  return blogArticles.find((article) => article.id === id);
}

export function getArticlesByCategory(category: string): BlogArticle[] {
  return blogArticles.filter((article) => article.category === category);
}

export function getAllCategories(): string[] {
  return Array.from(new Set(blogArticles.map((article) => article.category)));
}
