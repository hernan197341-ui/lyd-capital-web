import { MessageCircle, CheckCircle2 } from 'lucide-react';

/**
 * CTA Section Component
 * Design: Compelling call-to-action section to encourage WhatsApp consultation
 */
export default function CTASection() {
  const whatsappNumber = '+573142576858';
  const whatsappMessage = encodeURIComponent('Hola, me gustaría una consultoría personalizada sobre la Ley 2157 de 2021 y cómo L y D Capital puede ayudarme.');
  const whatsappLink = `https://wa.me/${whatsappNumber}?text=${whatsappMessage}`;

  const benefits = [
    'Asesoría personalizada sin costo',
    'Revisión de tu situación crediticia',
    'Plan de acción específico para tu caso',
    'Acompañamiento en todo el proceso'
  ];

  return (
    <section id="contacto" className="py-16 md:py-24 lg:py-32 bg-gradient-to-br from-blue-900 to-blue-800">
      <div className="container">
        <div className="max-w-4xl mx-auto">
          {/* Main Content */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 items-center">
            {/* Left Content */}
            <div className="space-y-6">
              <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-display font-bold text-white leading-tight">
                Comienza tu Recuperación Hoy
              </h2>
              <p className="text-sm sm:text-base md:text-lg text-blue-100 leading-relaxed">
                No esperes más. Nuestro equipo de expertos está listo para ayudarte a limpiar tu historial crediticio y recuperar tu estabilidad financiera.
              </p>

              {/* Benefits List */}
              <div className="space-y-3">
                {benefits.map((benefit, index) => (
                  <div key={index} className="flex items-start gap-3">
                    <CheckCircle2 className="w-6 h-6 text-green-400 flex-shrink-0 mt-0.5" />
                    <span className="text-blue-50">{benefit}</span>
                  </div>
                ))}
              </div>

              {/* CTA Button */}
              <a
                href={whatsappLink}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 bg-green-500 hover:bg-green-600 text-white font-bold py-4 px-8 rounded-lg transition-all duration-300 shadow-lg hover:shadow-xl text-lg w-full sm:w-auto justify-center"
              >
                <MessageCircle size={24} />
                Consulta Gratis por WhatsApp
              </a>
            </div>

            {/* Right Content - Image */}
            <div className="relative h-48 sm:h-64 md:h-96 w-full">
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663589446534/ew8NCBZTZqrhWkeojEJW8P/family-happiness-park-dpw95WQUsycjyYVs9r7tg7.webp"
                alt="Familia feliz disfrutando en un parque - recuperación financiera"
                className="w-full h-full object-cover rounded-xl shadow-lg"
              />
            </div>
          </div>

          {/* Bottom Info */}
          <div className="mt-8 sm:mt-12 pt-6 sm:pt-8 border-t border-blue-700">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6 text-center">
              <div className="bg-blue-800/50 p-4 rounded-lg">
                <p className="text-2xl sm:text-3xl font-bold text-green-400 mb-2">100%</p>
                <p className="text-sm sm:text-base text-blue-100">Confidencial y Seguro</p>
              </div>
              <div className="bg-blue-800/50 p-4 rounded-lg">
                <p className="text-2xl sm:text-3xl font-bold text-green-400 mb-2">24/7</p>
                <p className="text-sm sm:text-base text-blue-100">Disponible por WhatsApp</p>
              </div>
              <div className="bg-blue-800/50 p-4 rounded-lg">
                <p className="text-2xl sm:text-3xl font-bold text-green-400 mb-2">Gratis</p>
                <p className="text-sm sm:text-base text-blue-100">Primera Consulta sin Costo</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
