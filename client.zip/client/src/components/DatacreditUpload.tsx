import { useState } from 'react';
import { Upload, CheckCircle2, AlertCircle } from 'lucide-react';

/**
 * Datacrédito Upload Component
 * Design: Interactive drag-and-drop interface for PDF uploads
 * Provides visual feedback and next steps after upload
 */
export default function DatacreditUpload() {
  const [isDragging, setIsDragging] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [uploadStatus, setUploadStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      const file = files[0];
      if (file.type === 'application/pdf') {
        setUploadedFile(file);
        setUploadStatus('success');
        setTimeout(() => {
          console.log('File would be sent:', file.name);
        }, 500);
      } else {
        setUploadStatus('error');
      }
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.currentTarget.files;
    if (files && files.length > 0) {
      const file = files[0];
      if (file.type === 'application/pdf') {
        setUploadedFile(file);
        setUploadStatus('success');
      } else {
        setUploadStatus('error');
      }
    }
  };

  const whatsappNumber = '+573142576858';
  const whatsappMessage = encodeURIComponent(`Hola, adjunto mi reporte de Datacrédito: ${uploadedFile?.name || 'reporte.pdf'}. Necesito ayuda con la Ley 2157 de 2021.`);
  const whatsappLink = `https://wa.me/${whatsappNumber}?text=${whatsappMessage}`;

  const dragClass = isDragging
    ? 'border-green-500 bg-green-50'
    : 'border-slate-300 bg-slate-50 hover:border-blue-400 hover:bg-blue-50';

  return (
    <section id="datacredito" className="py-16 md:py-24 lg:py-32 bg-white">
      <div className="container">
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-12 md:mb-16">
          <h2 className="text-4xl md:text-5xl font-display font-bold text-blue-900 mb-4">
            Carga tu Reporte de Datacrédito
          </h2>
          <p className="text-lg text-slate-600">
            Sube tu reporte en PDF para que podamos revisar tu situación y ofrecerte la mejor asesoría personalizada.
          </p>
        </div>

        <div className="max-w-2xl mx-auto">
          {uploadStatus === 'idle' && (
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className={`border-2 border-dashed rounded-xl p-12 text-center transition-all duration-300 ${dragClass}`}
            >
              <Upload className="w-16 h-16 mx-auto mb-4 text-slate-400" />
              <h3 className="text-xl font-semibold text-slate-900 mb-2">Arrastra tu PDF aquí</h3>
              <p className="text-slate-600 mb-4">o</p>
              <label className="inline-block">
                <input
                  type="file"
                  accept=".pdf"
                  onChange={handleFileSelect}
                  className="hidden"
                />
                <span className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-6 rounded-lg cursor-pointer transition-colors inline-block">
                  Selecciona un archivo
                </span>
              </label>
              <p className="text-xs text-slate-500 mt-4">Solo archivos PDF (máximo 10 MB)</p>
            </div>
          )}

          {uploadStatus === 'success' && uploadedFile && (
            <div className="bg-green-50 border border-green-200 rounded-xl p-8 text-center">
              <CheckCircle2 className="w-16 h-16 mx-auto mb-4 text-green-600" />
              <h3 className="text-2xl font-semibold text-green-900 mb-2">¡Archivo Cargado!</h3>
              <p className="text-green-700 mb-4">{uploadedFile.name}</p>
              <p className="text-slate-600 mb-6">
                Perfecto. Ahora contacta con nosotros por WhatsApp para que podamos revisar tu reporte y ofrecerte la mejor asesoría.
              </p>
              <a
                href={whatsappLink}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white font-semibold py-3 px-8 rounded-lg transition-colors"
              >
                Enviar por WhatsApp
              </a>
              <button
                onClick={() => {
                  setUploadStatus('idle');
                  setUploadedFile(null);
                }}
                className="block mt-4 text-slate-600 hover:text-slate-900 font-medium text-sm"
              >
                Cargar otro archivo
              </button>
            </div>
          )}

          {uploadStatus === 'error' && (
            <div className="bg-red-50 border border-red-200 rounded-xl p-8 text-center">
              <AlertCircle className="w-16 h-16 mx-auto mb-4 text-red-600" />
              <h3 className="text-2xl font-semibold text-red-900 mb-2">Error en la Carga</h3>
              <p className="text-red-700 mb-6">Por favor, selecciona un archivo PDF válido.</p>
              <button
                onClick={() => setUploadStatus('idle')}
                className="inline-block bg-red-600 hover:bg-red-700 text-white font-semibold py-2 px-6 rounded-lg transition-colors"
              >
                Intentar de Nuevo
              </button>
            </div>
          )}
        </div>

        {/* Info Box */}
        <div className="mt-12 max-w-2xl mx-auto bg-blue-50 border border-blue-200 rounded-xl p-6">
          <h4 className="font-semibold text-blue-900 mb-3">¿Dónde obtener tu reporte de Datacrédito?</h4>
          <ul className="space-y-2 text-slate-700 text-sm">
            <li>• Descárgalo gratis en <strong>www.datacredito.com.co</strong></li>
            <li>• Accede con tu cédula de ciudadanía</li>
            <li>• Es gratuito consultar tu propio reporte</li>
            <li>• Recibirás un PDF con toda tu información crediticia</li>
          </ul>
        </div>
      </div>
    </section>
  );
}
