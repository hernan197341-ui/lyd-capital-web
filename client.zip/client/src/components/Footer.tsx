import { MessageCircle, Mail, Phone, Facebook, Instagram, Linkedin } from 'lucide-react';

/**
 * Footer Component
 * Design: Professional footer with contact information and social links
 * Structure: Company info (left) | Quick links (center) | Contact (right)
 */
export default function Footer() {
  const currentYear = new Date().getFullYear();
  const whatsappNumber = '+573142576858';
  const whatsappLink = `https://wa.me/${whatsappNumber}`;
  const phoneNumber = '3142576858';
  const email = 'info@lydcapital.com';

  return (
    <footer className="bg-slate-900 text-slate-300 py-12 md:py-16">
      <div className="container">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 sm:gap-8 mb-8 pb-8 border-b border-slate-700">
          {/* Company Info - Left */}
          <div className="sm:col-span-2 md:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-green-400 to-green-600 rounded-lg flex items-center justify-center flex-shrink-0">
                <span className="text-white font-display font-bold text-lg">LyD</span>
              </div>
              <h3 className="text-lg font-display font-bold text-white">L y D Capital</h3>
            </div>
            <p className="text-slate-400 text-sm leading-relaxed">
              Consultoría especializada en recuperación crediticia y Ley 2157 de 2021 (Borrón y Cuenta Nueva) en Colombia.
            </p>
          </div>

          {/* Quick Links - Center */}
          <div>
            <h4 className="text-white font-semibold mb-4 text-base">Enlaces Rápidos</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#ley" className="text-slate-400 hover:text-green-400 transition-colors">
                  Ley 2157 de 2021
                </a>
              </li>
              <li>
                <a href="#datacredito" className="text-slate-400 hover:text-green-400 transition-colors">
                  Carga de Datacrédito
                </a>
              </li>
              <li>
                <a href="#contacto" className="text-slate-400 hover:text-green-400 transition-colors">
                  Contacto
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Info - Right */}
          <div>
            <h4 className="text-white font-semibold mb-4 text-base">Contacto</h4>
            <div className="space-y-3 text-sm">
              <a
                href={whatsappLink}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-slate-400 hover:text-green-400 transition-colors"
              >
                <MessageCircle size={18} />
                WhatsApp
              </a>
              <a
                href={`mailto:${email}`}
                className="flex items-center gap-2 text-slate-400 hover:text-green-400 transition-colors"
              >
                <Mail size={18} />
                {email}
              </a>
              <a
                href={`tel:+57${phoneNumber}`}
                className="flex items-center gap-2 text-slate-400 hover:text-green-400 transition-colors"
              >
                <Phone size={18} />
                +57 {phoneNumber}
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="flex flex-col md:flex-row items-center justify-between text-sm text-slate-400 mb-6">
          <p>&copy; {currentYear} L y D Capital. Todos los derechos reservados.</p>
          <div className="flex gap-6 mt-4 md:mt-0">
            <a href="#" className="hover:text-green-400 transition-colors">
              Política de Privacidad
            </a>
            <a href="#" className="hover:text-green-400 transition-colors">
              Términos de Servicio
            </a>
          </div>
        </div>

        {/* Social Media Links - Placeholder for future */}
        <div className="flex justify-center gap-4 pt-6 border-t border-slate-700">
          <a
            href="#"
            title="Facebook"
            className="text-slate-400 hover:text-green-400 transition-colors"
            onClick={(e) => e.preventDefault()}
          >
            <Facebook size={20} />
          </a>
          <a
            href="#"
            title="Instagram"
            className="text-slate-400 hover:text-green-400 transition-colors"
            onClick={(e) => e.preventDefault()}
          >
            <Instagram size={20} />
          </a>
          <a
            href="#"
            title="LinkedIn"
            className="text-slate-400 hover:text-green-400 transition-colors"
            onClick={(e) => e.preventDefault()}
          >
            <Linkedin size={20} />
          </a>
        </div>

        {/* Disclaimer */}
        <div className="mt-8 pt-8 border-t border-slate-700 text-xs text-slate-500 text-center">
          <p>
            <strong>Descargo de responsabilidad:</strong> L y D Capital proporciona consultoría financiera y legal. La información en este sitio es educativa y no constituye asesoramiento legal profesional. Consulte con un abogado o asesor financiero certificado antes de tomar decisiones importantes.
          </p>
        </div>
      </div>
    </footer>
  );
}
