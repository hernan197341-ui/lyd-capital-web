import { CheckCircle2, Calendar, FileText, TrendingUp } from 'lucide-react';

/**
 * Law 2157 Section Component
 * Design: Information-rich section with icons and clear hierarchy
 * Explains the key benefits and timeline of the Borrón y Cuenta Nueva law
 */
export default function LawSection() {
  const benefits = [
    {
      icon: CheckCircle2,
      title: 'Eliminación de Reportes',
      description: 'Los reportes negativos se eliminan después de pagar tu deuda, en un plazo máximo de 4 años.'
    },
    {
      icon: Calendar,
      title: 'Caducidad Automática',
      description: 'Después de 8 años de mora, el reporte debe ser eliminado automáticamente, aunque no hayas pagado.'
    },
    {
      icon: FileText,
      title: 'Comunicación Previa',
      description: 'Las entidades deben notificarte 20 días antes de reportarte negativamente para que puedas actuar.'
    },
    {
      icon: TrendingUp,
      title: 'Recuperación Crediticia',
      description: 'Accede nuevamente a créditos, hipotecas y oportunidades financieras después de limpiar tu historial.'
    }
  ];

  return (
    <section id="ley" className="py-16 md:py-24 lg:py-32 bg-gradient-to-br from-blue-50 to-slate-50">
      <div className="container">
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-12 md:mb-16">
          <h2 className="text-4xl md:text-5xl font-display font-bold text-blue-900 mb-4">
            Ley 2157 de 2021: Borrón y Cuenta Nueva
          </h2>
          <p className="text-lg text-slate-600">
            Una ley que fortalece tu derecho al Habeas Data Financiero y te ofrece una segunda oportunidad para recuperar tu estabilidad crediticia.
          </p>
        </div>

        {/* Benefits Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 mb-12">
          {benefits.map((benefit, index) => {
            const Icon = benefit.icon;
            return (
              <div
                key={index}
                className="bg-white p-6 md:p-8 rounded-xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow duration-300"
              >
                <div className="flex gap-4">
                  <div className="flex-shrink-0">
                    <Icon className="w-8 h-8 text-green-600" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-blue-900 mb-2">{benefit.title}</h3>
                    <p className="text-slate-600 leading-relaxed">{benefit.description}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Key Information Box */}
        <div className="bg-white rounded-xl shadow-md border border-slate-200 p-8 md:p-10">
          <h3 className="text-2xl font-semibold text-blue-900 mb-6">¿Cómo Funciona?</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <div className="text-sm font-semibold text-green-600 uppercase tracking-wide">Paso 1</div>
              <h4 className="text-lg font-semibold text-slate-900">Identifica tu Deuda</h4>
              <p className="text-slate-600">Carga tu reporte de Datacrédito para revisar qué deudas tienes reportadas.</p>
            </div>
            <div className="space-y-2">
              <div className="text-sm font-semibold text-green-600 uppercase tracking-wide">Paso 2</div>
              <h4 className="text-lg font-semibold text-slate-900">Negocia y Paga</h4>
              <p className="text-slate-600">Contacta a tus acreedores para negociar un acuerdo de pago o reestructuración.</p>
            </div>
            <div className="space-y-2">
              <div className="text-sm font-semibold text-green-600 uppercase tracking-wide">Paso 3</div>
              <h4 className="text-lg font-semibold text-slate-900">Recupera tu Crédito</h4>
              <p className="text-slate-600">Una vez pagada, tu reporte se elimina y recuperas tu acceso al sistema financiero.</p>
            </div>
          </div>
        </div>

        {/* Important Note */}
        <div className="mt-8 p-4 bg-blue-50 border-l-4 border-blue-500 rounded">
          <p className="text-sm text-slate-700">
            <strong>Nota importante:</strong> La Ley 2157 de 2021 entró en vigor el 29 de octubre de 2021. Si tienes reportes negativos, esta ley te protege y ofrece oportunidades para limpiar tu historial crediticio.
          </p>
        </div>
      </div>
    </section>
  );
}
