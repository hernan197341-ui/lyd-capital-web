import { MessageCircle, Menu, X } from 'lucide-react';
import { useState } from 'react';

/**
 * Header Component - Professional Navigation
 * Design: Responsive header with hamburger menu on mobile and WhatsApp CTA button
 */
export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const whatsappNumber = '+573142576858'; // L y D Capital WhatsApp
  const whatsappMessage = encodeURIComponent('Hola, me gustaría consultar sobre la Ley 2157 de 2021 y cómo L y D Capital puede ayudarme.');
  const whatsappLink = `https://wa.me/${whatsappNumber}?text=${whatsappMessage}`;

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-slate-200 shadow-sm">
      <div className="container flex items-center justify-between h-16 sm:h-20">
        {/* Logo */}
        <div className="flex items-center gap-2 flex-shrink-0">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-900 to-blue-700 rounded-lg flex items-center justify-center">
            <span className="text-white font-display font-bold text-lg">LyD</span>
          </div>
          <div className="hidden sm:block">
            <h1 className="text-lg font-display font-bold text-blue-900">L y D Capital</h1>
            <p className="text-xs text-slate-600">Consultoría Financiera</p>
          </div>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-8">
          <a href="/services" className="text-slate-700 hover:text-blue-900 transition-colors font-medium text-sm">
            Servicios
          </a>
          <a href="#ley" className="text-slate-700 hover:text-blue-900 transition-colors font-medium text-sm">
            Ley 2157
          </a>
          <a href="#datacredito" className="text-slate-700 hover:text-blue-900 transition-colors font-medium text-sm">
            Carga de Datacrédito
          </a>
          <a href="#contacto" className="text-slate-700 hover:text-blue-900 transition-colors font-medium text-sm">
            Contacto
          </a>
        </nav>

        {/* Right Section - WhatsApp Button + Mobile Menu Toggle */}
        <div className="flex items-center gap-3">
          {/* WhatsApp Button */}
          <a
            href={whatsappLink}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1 sm:gap-2 bg-green-500 hover:bg-green-600 text-white font-semibold py-2 px-3 sm:px-4 rounded-lg transition-all duration-300 shadow-md hover:shadow-lg text-xs sm:text-sm flex-shrink-0"
          >
            <MessageCircle size={16} className="sm:w-5 sm:h-5" />
            <span className="hidden sm:inline">WhatsApp</span>
          </a>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-slate-700 hover:text-blue-900 transition-colors flex-shrink-0"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <nav className="md:hidden bg-white border-t border-slate-200">
          <div className="container py-4 space-y-3">
            <a
              href="/services"
              onClick={() => setMobileMenuOpen(false)}
              className="block text-slate-700 hover:text-blue-900 transition-colors font-medium py-2"
            >
              Servicios
            </a>
            <a
              href="#ley"
              onClick={() => setMobileMenuOpen(false)}
              className="block text-slate-700 hover:text-blue-900 transition-colors font-medium py-2"
            >
              Ley 2157
            </a>
            <a
              href="#datacredito"
              onClick={() => setMobileMenuOpen(false)}
              className="block text-slate-700 hover:text-blue-900 transition-colors font-medium py-2"
            >
              Carga de Datacrédito
            </a>
            <a
              href="#contacto"
              onClick={() => setMobileMenuOpen(false)}
              className="block text-slate-700 hover:text-blue-900 transition-colors font-medium py-2"
            >
              Contacto
            </a>
          </div>
        </nav>
      )}
    </header>
  );
}
