import { ArrowRight } from 'lucide-react';

/**
 * Hero Section Component
 * Design: Asymmetric layout with text on left, image on right
 * Uses professional financial recovery image to establish trust
 */
export default function HeroSection() {
  const whatsappNumber = '+573142576858';
  const whatsappMessage = encodeURIComponent('Hola, me gustaría consultar sobre la Ley 2157 de 2021 y cómo L y D Capital puede ayudarme.');
  const whatsappLink = `https://wa.me/${whatsappNumber}?text=${whatsappMessage}`;

  return (
    <section className="relative py-16 md:py-24 lg:py-32 overflow-hidden">
      <div className="container grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 items-center">
        {/* Left Content */}
        <div className="space-y-6 md:space-y-8">
          <div className="space-y-3 sm:space-y-4">
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-display font-bold text-blue-900 leading-tight">
              Recupera tu Estabilidad Financiera
            </h1>
            <p className="text-sm sm:text-base md:text-lg lg:text-xl text-slate-600 leading-relaxed">
              Con la Ley 2157 de 2021, tienes una segunda oportunidad. Limpia tu historial crediticio y accede nuevamente a créditos, vivienda y oportunidades financieras.
            </p>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 gap-3 sm:gap-4">
            <div className="bg-blue-50 p-3 sm:p-4 rounded-lg border border-blue-100">
              <p className="text-xl sm:text-2xl font-bold text-blue-900">4 años</p>
              <p className="text-xs sm:text-sm text-slate-600">Máximo de permanencia del reporte</p>
            </div>
            <div className="bg-green-50 p-3 sm:p-4 rounded-lg border border-green-100">
              <p className="text-xl sm:text-2xl font-bold text-green-700">100% Legal</p>
              <p className="text-xs sm:text-sm text-slate-600">Respaldado por la ley colombiana</p>
            </div>
          </div>

          {/* CTA Button */}
          <a
            href={whatsappLink}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-green-500 hover:bg-green-600 text-white font-semibold py-3 px-8 rounded-lg transition-all duration-300 shadow-md hover:shadow-lg w-full sm:w-auto justify-center sm:justify-start"
          >
            Consulta Gratis por WhatsApp
            <ArrowRight size={20} />
          </a>
        </div>

        {/* Right Image */}
        <div className="relative h-64 md:h-96 lg:h-full md:min-h-96">
          <img
            src="https://d2xsxph8kpxj0f.cloudfront.net/310519663589446534/ew8NCBZTZqrhWkeojEJW8P/hero-financial-recovery-4o5mrK2maaoVtQLqZjsaZo.webp"
            alt="Profesional revisando documentos financieros"
            className="w-full h-full object-cover rounded-2xl shadow-2xl"
          />
          {/* Decorative overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-blue-900/20 to-transparent rounded-2xl" />
        </div>
      </div>

      {/* Decorative element */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-blue-50 rounded-full -z-10 blur-3xl opacity-50" />
    </section>
  );
}
